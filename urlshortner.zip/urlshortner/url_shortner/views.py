from django.shortcuts import render,redirect
import pyshorteners
# Create your views here.
def index(request):
    if request.method=="POST":
        url=request.POST['url']
        pys=pyshorteners.Shortener()
        short_url=pys.tinyurl.short(url)
        return render(request,"index.html",{'url':short_url})
    else:
        return render(request,'index.html')

